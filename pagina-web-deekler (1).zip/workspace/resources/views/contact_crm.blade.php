@extends('admin.template.crm') 

@section('Content')
@include ('admin.template.partials.crm')


@stop