
<header class="header-area">
        <!-- Navigation start -->
        <nav class="navbar navbar-custom tb-nav" role="navigation">
            <div class="container">        
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#tb-nav-collapse">
                  <span class="sr-only">Deekler</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand logo" href="#"><img style="max-width:200px; margin-top: -17px;"
             src="extra/theme/img/company_logo.png"></a>
              </div>
          
              <div class="collapse navbar-collapse" id="tb-nav-collapse">
          
                <ul class="nav navbar-nav navbar-right">
                    <li class="active"><a class="page-scroll" href="#top">Home</a></li>
                   
                    <li><a class="page-scroll" href="#service">Services</a></li>
                    <li><a class="page-scroll" href="#testimonial">Testimonials</a></li>
                    <li><a class="page-scroll" href="#portfolio">Portfolio</a></li>
                    <li><a class="page-scroll" href="#contact">Contact us</a></li>
                </ul>
              </div>
            </div>
        </nav>
    </header>
