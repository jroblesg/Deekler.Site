<!--<section class="hero-section static-bg" id="top">-->
<!--                <div class="slider-caption">-->
<!--                    <div class="container">-->
<!--                        <div class="row">-->
                            <!-- Hero Title -->
<!--                            <h1>Welcome to <span>Deekler</span></h1>-->
                            <!-- Hero Subtitle -->
<!--                            <h5>Ideas + Code = Deekler</h5>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--</section>-->

<!-- hero-section -->
    <section class="hero-section hero-particle-bg" id="top" data-stellar-background-ratio="0.1">
        <div id="particles-js"></div>
        <div class="slider-caption">
            <div class="container">
                <div class="row">
                    <h1>We find<br> <span> the solution </span></h1>
                    <h5>Websites and CRM software</h5>
                </div>
            </div>
        </div>

    </section>
    <!-- End Of Hero Section -->