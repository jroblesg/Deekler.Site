<!-- Footer Section -->

    <footer class="footer-section">
        <div class="container">
            <div class="row mt-30 mb-30">
                <div class="col-md-12 text-center">
                    <!-- Footer Copy Right Text -->
                    <div class="copyright-info">
                        <a href="http://deekler.com"><span> © 2016 Deekler.com, all right reserved</span></a>
                    </div>

                    <!-- Footer Social Icons -->
                    <div class="social-icons mt-30">
                        <a href="https://www.facebook.com/themebite/"><i class="fa fa-facebook"></i></a>
                        <a href="https://twitter.com/themebite/"><i class="fa fa-twitter"></i></a>
                        <a href="https://plus.google.com/themebite/"><i class="fa fa-google-plus"></i></a>
                        <a href="https://github.com/themebite/"><i class="fa fa-github"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- End Of Footer Section -->