@extends('admin.template.cms')
@section('Content')
@include('admin.template.partials.cms')

@stop