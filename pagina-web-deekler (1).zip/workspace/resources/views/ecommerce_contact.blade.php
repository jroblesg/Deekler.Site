@extends('admin.template.ecommerce')
@section('Content')
@include('admin.template.partials.ecommerce')

@stop