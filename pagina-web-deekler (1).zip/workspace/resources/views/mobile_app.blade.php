@extends('admin.template.mobile_app')
@section('Content')
@include('admin.template.partials.mobile_app')

@stop