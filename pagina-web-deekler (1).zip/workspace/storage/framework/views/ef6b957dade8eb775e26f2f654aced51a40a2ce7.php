 

<?php $__env->startSection('Content'); ?>
<?php echo $__env->make('admin.template.partials.crm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.crm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>