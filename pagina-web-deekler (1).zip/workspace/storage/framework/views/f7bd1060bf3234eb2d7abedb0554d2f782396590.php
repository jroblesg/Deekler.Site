<?php $__env->startSection('Content'); ?>
<?php echo $__env->make('admin.template.partials.cms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.cms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>