<?php $__env->startSection('Content'); ?>

<?php echo $__env->make('admin.template.partials.our_services', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.csm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>