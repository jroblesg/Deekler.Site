<?php $__env->startSection('Content'); ?>
<?php echo $__env->make('admin.template.partials.ecommerce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.ecommerce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>